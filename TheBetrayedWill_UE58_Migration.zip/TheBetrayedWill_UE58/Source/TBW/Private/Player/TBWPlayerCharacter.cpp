// The Betrayed Will / وصية الغدر
// Copyright (c) 2026. All rights reserved.

#include "Player/TBWPlayerCharacter.h"
#include "Player/TBWPlayerIdentityComponent.h"
#include "Player/TBWIdentityFactory.h"
#include "Player/TBWIdentityData.h"
#include "Player/TBWPlayerController.h"
#include "Input/TBWInputConfig.h"
#include "Interaction/TBWInteractorComponent.h"
#include "Camera/CameraComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/StaticMesh.h"
#include "EnhancedInputComponent.h"
#include "UObject/ConstructorHelpers.h"
#include "TBW.h"

ATBWPlayerCharacter::ATBWPlayerCharacter()
{
	PrimaryActorTick.bCanEverTick = true;

	bUseControllerRotationPitch = false;
	bUseControllerRotationYaw = false;
	bUseControllerRotationRoll = false;

	GetCapsuleComponent()->InitCapsuleSize(38.f, 88.f);

	UCharacterMovementComponent* MoveComp = GetCharacterMovement();
	MoveComp->bOrientRotationToMovement = true;
	MoveComp->RotationRate = FRotator(0.f, 480.f, 0.f);
	MoveComp->MaxWalkSpeed = 420.f;
	MoveComp->MaxWalkSpeedCrouched = 160.f;
	MoveComp->NavAgentProps.bCanCrouch = true;
	MoveComp->SetCrouchedHalfHeight(58.f);
	MoveComp->BrakingDecelerationWalking = 1400.f;
	MoveComp->GroundFriction = 8.f;
	MoveComp->JumpZVelocity = 0.f;
	MoveComp->AirControl = 0.f;

	CameraBoom = CreateDefaultSubobject<USpringArmComponent>(TEXT("CameraBoom"));
	CameraBoom->SetupAttachment(RootComponent);
	CameraBoom->TargetArmLength = DefaultBoomLength;
	CameraBoom->bUsePawnControlRotation = true;
	CameraBoom->SocketOffset = FVector(0.f, 55.f, 62.f);
	CameraBoom->bEnableCameraLag = true;
	CameraBoom->CameraLagSpeed = 12.f;
	CameraBoom->bEnableCameraRotationLag = true;
	CameraBoom->CameraRotationLagSpeed = 18.f;
	CameraBoom->ProbeSize = 12.f;

	FollowCamera = CreateDefaultSubobject<UCameraComponent>(TEXT("FollowCamera"));
	FollowCamera->SetupAttachment(CameraBoom, USpringArmComponent::SocketName);
	FollowCamera->bUsePawnControlRotation = false;
	FollowCamera->FieldOfView = 78.f;

	PreviewBody = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("PreviewBody"));
	PreviewBody->SetupAttachment(GetCapsuleComponent());
	PreviewBody->SetRelativeLocation(FVector(0.f, 0.f, -88.f));
	PreviewBody->SetRelativeScale3D(FVector(0.38f, 0.38f, 1.72f));
	PreviewBody->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	static ConstructorHelpers::FObjectFinder<UStaticMesh> CubeFinder(TEXT("/Engine/BasicShapes/Cube.Cube"));
	if (CubeFinder.Succeeded())
	{
		PreviewBody->SetStaticMesh(CubeFinder.Object);
	}

	IdentityComponent = CreateDefaultSubobject<UTBWPlayerIdentityComponent>(TEXT("Identity"));
	Interactor = CreateDefaultSubobject<UTBWInteractorComponent>(TEXT("Interactor"));
}

void ATBWPlayerCharacter::BeginPlay()
{
	Super::BeginPlay();

	if (IdentityComponent && !IdentityComponent->GetIdentity())
	{
		IdentityComponent->ApplyIdentity(FTBWIdentityFactory::MakeEvan(this));
	}
	ApplyMovementFromIdentity();

	UE_LOG(LogTBW, Log, TEXT("Player ready. Phase 1 movement/camera/interact. No combat."));
}

void ATBWPlayerCharacter::PossessedBy(AController* NewController)
{
	Super::PossessedBy(NewController);
}

void ATBWPlayerCharacter::ApplyMovementFromIdentity()
{
	const UTBWIdentityData* Data = IdentityComponent ? IdentityComponent->GetIdentity() : nullptr;
	WalkSpeed = Data ? Data->MaxWalkSpeed : 420.f;
	SprintSpeed = Data ? Data->MaxSprintSpeed : 620.f;
	CrouchSpeed = Data ? Data->MaxCrouchSpeed : 160.f;
	if (UCharacterMovementComponent* MoveComp = GetCharacterMovement())
	{
		MoveComp->MaxWalkSpeed = WalkSpeed;
		MoveComp->MaxWalkSpeedCrouched = CrouchSpeed;
	}
}

void ATBWPlayerCharacter::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	UCharacterMovementComponent* MoveComp = GetCharacterMovement();
	if (MoveComp && !bIsCrouched)
	{
		const bool bMoving = !MoveComp->Velocity.IsNearlyZero(10.f);
		MoveComp->MaxWalkSpeed = (bWantsSprint && bMoving) ? SprintSpeed : WalkSpeed;
	}

	UpdateCamera(DeltaSeconds);
}

void ATBWPlayerCharacter::UpdateCamera(float DeltaSeconds)
{
	if (!CameraBoom)
	{
		return;
	}

	const bool bSprinting = bWantsSprint && !bIsCrouched;
	const float TargetLength = bIsCrouched ? CrouchBoomLength : (bSprinting ? SprintBoomLength : DefaultBoomLength);
	const FVector TargetOffset = bIsCrouched ? FVector(0.f, 48.f, 38.f) : FVector(0.f, 55.f, 62.f);

	CameraBoom->TargetArmLength = FMath::FInterpTo(CameraBoom->TargetArmLength, TargetLength, DeltaSeconds, 6.f);
	CameraBoom->SocketOffset = FMath::VInterpTo(CameraBoom->SocketOffset, TargetOffset, DeltaSeconds, 6.f);
}

void ATBWPlayerCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

	UEnhancedInputComponent* Enhanced = Cast<UEnhancedInputComponent>(PlayerInputComponent);
	if (!Enhanced)
	{
		UE_LOG(LogTBW, Error, TEXT("Enhanced Input component missing."));
		return;
	}

	ATBWPlayerController* PC = Cast<ATBWPlayerController>(Controller);
	UTBWInputConfig* Input = PC ? PC->GetInputConfig() : nullptr;
	if (!Input)
	{
		UE_LOG(LogTBW, Warning, TEXT("InputConfig missing on controller. Movement will be dead."));
		return;
	}

	Enhanced->BindAction(Input->MoveAction, ETriggerEvent::Triggered, this, &ATBWPlayerCharacter::Move);
	Enhanced->BindAction(Input->LookAction, ETriggerEvent::Triggered, this, &ATBWPlayerCharacter::Look);
	Enhanced->BindAction(Input->SprintAction, ETriggerEvent::Started, this, &ATBWPlayerCharacter::SprintStarted);
	Enhanced->BindAction(Input->SprintAction, ETriggerEvent::Completed, this, &ATBWPlayerCharacter::SprintEnded);
	Enhanced->BindAction(Input->CrouchAction, ETriggerEvent::Started, this, &ATBWPlayerCharacter::CrouchStarted);
	Enhanced->BindAction(Input->CrouchAction, ETriggerEvent::Completed, this, &ATBWPlayerCharacter::CrouchEnded);
	Enhanced->BindAction(Input->InteractAction, ETriggerEvent::Started, this, &ATBWPlayerCharacter::InteractPressed);
	Enhanced->BindAction(Input->PrimaryAction, ETriggerEvent::Started, this, &ATBWPlayerCharacter::PrimaryPressed);
	Enhanced->BindAction(Input->SecondaryAction, ETriggerEvent::Started, this, &ATBWPlayerCharacter::SecondaryPressed);
	Enhanced->BindAction(Input->PauseAction, ETriggerEvent::Started, this, &ATBWPlayerCharacter::PausePressed);
}

void ATBWPlayerCharacter::Move(const FInputActionValue& Value)
{
	const FVector2D Axis = Value.Get<FVector2D>();
	if (Controller == nullptr)
	{
		return;
	}

	const FRotator Yaw(0.f, Controller->GetControlRotation().Yaw, 0.f);
	const FRotationMatrix Matrix(Yaw);
	AddMovementInput(Matrix.GetUnitAxis(EAxis::X), Axis.Y);
	AddMovementInput(Matrix.GetUnitAxis(EAxis::Y), Axis.X);
}

void ATBWPlayerCharacter::Look(const FInputActionValue& Value)
{
	const FVector2D Axis = Value.Get<FVector2D>();
	AddControllerYawInput(Axis.X * LookYawScale);
	AddControllerPitchInput(Axis.Y * LookPitchScale);
}

void ATBWPlayerCharacter::SprintStarted(const FInputActionValue& Value)
{
	bWantsSprint = true;
}

void ATBWPlayerCharacter::SprintEnded(const FInputActionValue& Value)
{
	bWantsSprint = false;
}

void ATBWPlayerCharacter::CrouchStarted(const FInputActionValue& Value)
{
	if (bCrouchToggle)
	{
		if (bIsCrouched)
		{
			UnCrouch();
		}
		else
		{
			Crouch();
		}
	}
	else
	{
		Crouch();
	}
}

void ATBWPlayerCharacter::CrouchEnded(const FInputActionValue& Value)
{
	if (!bCrouchToggle)
	{
		UnCrouch();
	}
}

void ATBWPlayerCharacter::InteractPressed(const FInputActionValue& Value)
{
	if (Interactor)
	{
		Interactor->TryInteract();
	}
}

void ATBWPlayerCharacter::PrimaryPressed(const FInputActionValue& Value)
{
	UE_LOG(LogTBW, Verbose, TEXT("Primary action reserved for Phase 3 combat."));
}

void ATBWPlayerCharacter::SecondaryPressed(const FInputActionValue& Value)
{
	UE_LOG(LogTBW, Verbose, TEXT("Secondary action reserved for Phase 3 combat."));
}

void ATBWPlayerCharacter::PausePressed(const FInputActionValue& Value)
{
	if (ATBWPlayerController* PC = Cast<ATBWPlayerController>(Controller))
	{
		PC->TogglePauseMenu();
	}
}
